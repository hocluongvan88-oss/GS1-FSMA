{
  "appId": "2993388261247205445",
  "listPages": [
    "pages/index"
  ],
  "window": {
    "title": "Vexim Global GS1",
    "navigationBarTitleText": "Vexim Global GS1",
    "navigationBarBackgroundColor": "#10b981",
    "navigationBarTextStyle": "white",
    "backgroundColor": "#ffffff"
  },
  "permission": {
    "scope.userInfo": "Lấy thông tin người dùng",
    "scope.userPhonenumber": "Lấy số điện thoại",
    "scope.camera": "Truy cập camera để quét mã GS1"
  }
}